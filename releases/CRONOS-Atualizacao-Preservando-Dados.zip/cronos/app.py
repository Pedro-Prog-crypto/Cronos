import asyncio
import json
import re
import secrets
from pathlib import Path
from contextlib import asynccontextmanager
from contextlib import suppress
from uuid import UUID, uuid4

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from cronos.config import Settings
from cronos.memory import Memory
from cronos.providers import ProviderError
from cronos import delivery
from cronos.engine import Engine, TurnError
from cronos.integrations import provider_catalog, available_models
from cronos.tools import create_registry, ToolError
from cronos.security import SecurityMiddleware
from cronos.monitor import Monitor
from cronos.missions import Missions
from cronos.features import Features
from cronos.windows_system import WindowsSystem
from cronos.geography import install_geography
from cronos.control import install_routes
from cronos.panels import PanelState, install_panels


class ChatInput(BaseModel):
    message: str = Field(min_length=1, max_length=16000)
    session_id: UUID | None = None
    heard_context: str | None = Field(default=None, max_length=10000)


class SpeechInput(BaseModel):
    text: str = Field(min_length=1, max_length=50000)
    reference_id: str | None = Field(default=None, max_length=128)
    speed: float | None = Field(default=None, ge=0.5, le=2.0)

    @field_validator('text')
    @classmethod
    def spoken_prose(cls,value):
        from cronos.spoken_text import speech_text
        clean=speech_text(value)
        if not clean:raise ValueError('Não há texto de conversa para falar. Código e registros ficam na tela.')
        return clean


class ApprovalInput(BaseModel):
    session_id: UUID
    accepted: bool


VOICE_REQUEST_TIMEOUT_SECONDS = 30
TRANSCRIPTION_TIMEOUT_SECONDS = 30
TRANSCRIPTION_TOTAL_TIMEOUT_SECONDS = 40
CONVERSATION_FIRST_REPLY_TIMEOUT_SECONDS = 24


async def voice_deadline(operation, seconds):
    try:
        async with asyncio.timeout(seconds):
            return await operation
    except TimeoutError:
        raise HTTPException(504, 'O serviço de voz não respondeu a tempo.') from None


async def chat_until_disconnect(engine,session,message,request):
    if await request.is_disconnected():raise HTTPException(499,'Conversa interrompida.')
    task=asyncio.create_task(engine.chat(session,message))
    async def watch():
        while not task.done():
            if await request.is_disconnected():return
            await asyncio.sleep(.1)
    watcher=asyncio.create_task(watch())
    try:
        done,_=await asyncio.wait({task,watcher},return_when=asyncio.FIRST_COMPLETED,timeout=CONVERSATION_FIRST_REPLY_TIMEOUT_SECONDS)
        if not done:raise HTTPException(504,'A conversa não concluiu dentro do prazo de recuperação. Sua pergunta permanece disponível para tentar novamente.')
        if task in done:return await task
        task.cancel()
        with suppress(asyncio.CancelledError):await task
        raise HTTPException(499,'Conversa interrompida antes da resposta.')
    finally:
        watcher.cancel()
        if not task.done():task.cancel()
        await asyncio.gather(task,watcher,return_exceptions=True)


class MemoryQuery(BaseModel):
    query: str = Field(min_length=1, max_length=3000)
    limit: int = Field(default=8, ge=1, le=100)


def create_app(settings: Settings | None = None, provider=None, fish_factory=None, vision_provider=None,
               windows_runner=None, windows_platform=None):
    settings = settings or Settings.from_env()
    from cronos.recognition import LocalRecognizer
    local_recognizer=LocalRecognizer()

    @asynccontextmanager
    async def lifespan(app):
        app.state.delivery=delivery.DeliveryLog()
        app.state.memory = Memory(settings.vault)
        app.state.lock = asyncio.Lock()
        app.state.monitor = Monitor(settings, app.state.memory)
        app.state.windows = WindowsSystem(windows_runner, app.state.monitor, windows_platform, settings.privacy_mode)
        app.state.missions = Missions(app.state.memory)
        app.state.registry = create_registry(settings, app.state.memory, app.state.monitor, app.state.windows, app.state.missions, app.state.prospects, updates=app.state.updater)
        app.state.engine = Engine(settings, app.state.memory, app.state.registry, provider)
        app.state.vision_provider = vision_provider
        from cronos.live_screen import LiveScreen
        app.state.live_screen=LiveScreen()
        app.state.engine.live_screen=app.state.live_screen
        app.state.features = Features(app)
        app.state.panels = PanelState(app)
        from cronos.studio.service import Studio
        import sqlite3
        app.state.studio = None
        try:
            app.state.studio = Studio(app)
        except (OSError, ValueError, sqlite3.Error):
            app.state.studio_error = 'Não foi possível abrir a base local do Estúdio. Os dados foram mantidos; confira acesso e cópia de segurança. A conversa continua disponível.'
            app.state.registry.load_errors.append(app.state.studio_error)
        panel_task = asyncio.create_task(app.state.panels.maintain())
        await asyncio.to_thread(app.state.monitor.collect)
        task = asyncio.create_task(app.state.monitor.run())
        windows_task = asyncio.create_task(app.state.windows.watch())
        async def warm_recognition():
            if settings.transcription_provider!='vosk' and not app.state.panels.preferences.called_only:return
            try:await asyncio.to_thread(local_recognizer.prepare)
            except ValueError:pass # The transcription endpoint reports configuration errors on use.
        recognition_task=asyncio.create_task(warm_recognition())
        update_task=asyncio.create_task(app.state.updater.maintain())
        eye_task=asyncio.create_task(app.state.eye.maintain())
        try:
            yield
        finally:
            if app.state.engine.memory_refresh is not None:
                await asyncio.gather(app.state.engine.memory_refresh, return_exceptions=True)
            await app.state.live_screen.close()
            if app.state.studio is not None: await app.state.studio.close()
            update_task.cancel()
            with suppress(asyncio.CancelledError):await update_task
            if app.state.updater.task and not app.state.updater.task.done():
                app.state.updater.task.cancel()
                with suppress(asyncio.CancelledError):await app.state.updater.task
            eye_task.cancel()
            with suppress(asyncio.CancelledError):await eye_task
            await app.state.eye.close()
            panel_task.cancel()
            with suppress(asyncio.CancelledError):await panel_task
            recognition_task.cancel()
            with suppress(asyncio.CancelledError):await recognition_task
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
            windows_task.cancel()
            with suppress(asyncio.CancelledError):
                await windows_task
            await app.state.windows.close()

    app = FastAPI(title="Cronos", version="0.5.0", lifespan=lifespan, docs_url=None, redoc_url=None)
    from cronos.live_screen import install as install_live_screen
    from cronos.voice_interrupt import install_interrupt
    install_interrupt(app,settings,local_recognizer)
    static = Path(__file__).parent / "static"
    app.mount("/static", StaticFiles(directory=static), name="static")
    ui = Path(__file__).parent / "ui"
    if ui.is_dir():
        app.mount("/ui", StaticFiles(directory=ui), name="ui")

    @app.get("/", include_in_schema=False)
    async def interface():
        return FileResponse(ui / "index.html" if (ui / "index.html").is_file() else static / "index.html", headers={"Cache-Control": "no-store"})

    @app.get("/world/view", include_in_schema=False)
    async def world_view():
        return FileResponse(Path(__file__).parent/'eye-ui/index.html', headers={'Cache-Control':'no-store'})

    @app.get("/tests", include_in_schema=False)
    async def workbench():
        return FileResponse(static / "index.html", headers={"Cache-Control": "no-store"})

    if settings.origins:
        app.add_middleware(CORSMiddleware, allow_origins=list(settings.origins),
                           allow_methods=["GET", "POST", "PATCH"], allow_headers=["Authorization", "Content-Type"])
    app.add_middleware(SecurityMiddleware, settings=settings)

    async def authenticate(authorization: str | None = Header(default=None)):
        if not settings.token:
            raise HTTPException(503, "Configure CRONOS_API_TOKEN antes de acessar os dados.")
        if not secrets.compare_digest((authorization or "").encode('utf-8'), ("Bearer " + settings.token).encode('utf-8')):
            raise HTTPException(401, "Autenticação necessária.")

    @app.get('/connection')
    async def reconnect(request: Request):
        import os
        if (os.getenv('CRONOS_SUPERVISED')!='1' or request.headers.get('sec-fetch-site') not in {'same-origin','none'}
                or not settings.token or not secrets.compare_digest(request.cookies.get('cronos_browser_session','').encode('utf-8'),settings.token.encode('utf-8'))):
            raise HTTPException(401,'Sessão local indisponível. Abra pelo iniciador do Cronos.')
        return {'token':settings.token}

    from cronos.updates import install_updates
    install_updates(app, authenticate)

    from cronos.stremio import install_stremio
    install_stremio(app,authenticate)

    from cronos.music import install_music
    install_music(app, authenticate)
    from cronos.prospects import install_prospects
    install_prospects(app, authenticate)
    from cronos.eye_runtime import install_eye
    install_eye(app,authenticate)

    @app.middleware('http')
    async def panel_metrics(request, call_next):
        measured = request.url.path in {'/chat', '/voice/speech', '/voice/transcribe', '/vision/analyze'}
        panels = getattr(request.app.state, 'panels', None)
        if measured and panels:panels.active += 1
        try:return await call_next(request)
        finally:
            if measured and panels:
                panels.active -= 1
                panels.requests += 1
                if request.url.path=='/chat':request.app.state.engine.phase="idle"

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/monitor", dependencies=[Depends(authenticate)])
    async def monitor(request: Request, after: int = Query(default=0, ge=0)):
        return request.app.state.monitor.snapshot(after)

    @app.post("/monitor/alerts/{alert_id}/ack", dependencies=[Depends(authenticate)])
    async def acknowledge_alert(alert_id: int, request: Request):
        if not request.app.state.monitor.acknowledge(alert_id):
            raise HTTPException(404, "Alerta ativo não encontrado.")
        return {"acknowledged": True}

    @app.get("/status", dependencies=[Depends(authenticate)])
    async def status(response: Response):
        import os
        if os.getenv('CRONOS_SUPERVISED')=='1':
            response.set_cookie('cronos_browser_session',settings.token,httponly=True,samesite='strict',path='/connection')
        current = app.state.engine.settings
        warning = None
        try:
            configured = next((p['configured'] for p in provider_catalog(current) if p['id'] == current.provider), False)
        except ProviderError as exc:
            configured = bool(settings.gemini_key) if settings.provider == 'gemini' else settings.provider == 'ollama'
            warning = str(exc)
        return {"provider": current.provider, "gemini_configured": bool(settings.gemini_key),
                "provider_model": next((item['model'] for item in provider_catalog(current) if item['id'] == current.provider), None) if warning is None else None,
                "provider_configured": configured, "configuration_warning": warning,
                "privacy_mode": settings.privacy_mode,
                "fish_configured": bool(settings.fish_key) and settings.privacy_mode == 'online',
                "transcription_provider": settings.transcription_provider,
                "local_voice_interrupt":True,
                # Prefer the explicitly configured speech recognizer when it is
                # available. Native Live audio bypasses Fish/Vosk and cannot
                # use the normal text-provider failover after recognition.
                "direct_audio_chat":current.privacy_mode=="online" and current.provider=="gemini" and current.gemini_transport=="live" and not (
                    current.transcription_provider == "vosk" or
                    current.transcription_provider == "fish" and bool(current.fish_key) and current.privacy_mode == "online"
                ),
                "fish_model_in_use": active_fish_model,
                "fish_pcm_streaming": active_fish_model=="s2.1-pro-free" and settings.privacy_mode=="online",
                "fish_speech_configured": bool(settings.fish_key and settings.fish_model) and settings.privacy_mode == "online",
                "custom_voice_configured": bool(settings.fish_reference),
                "personality_available": settings.personality.is_file()}

    install_live_screen(app,authenticate)
    from cronos.hand_control import install as install_hand_control
    install_hand_control(app,settings)

    @app.post("/chat", dependencies=[Depends(authenticate)])
    async def chat(body: ChatInput, request: Request):
        if not body.message.strip():
            raise HTTPException(422, "A mensagem não pode ser vazia.")
        session = body.session_id or uuid4()
        # Uma instância/worker: protege ordem das conversas e arquivos compartilhados.
        async with request.app.state.lock:
            try:
                result = await chat_until_disconnect(request.app.state.engine,session,body.message,request)
            except TurnError as exc:
                raise HTTPException(exc.status, {"message": str(exc), "session_id": str(exc.session), "tool_results": exc.results}) from exc
            except ProviderError as exc:
                raise HTTPException(exc.status, str(exc)) from exc
            except (OSError, ValueError):
                raise HTTPException(500, "Não foi possível ler ou salvar personalidade/memória.")
        request.app.state.features.record("language", "passed", "Uma conversa foi processada e salva. Não certifica precisão de todas as respostas.")
        return result

    async def conversation_stream(session,message,request,audio=None,audio_fallback=None,heard_context=None):
        from cronos.reply_stream import reply_sink,intro_sink,transcript_sink
        async def events():
            panels=request.app.state.panels;panels.active+=1
            queue=asyncio.Queue(maxsize=4);spoken=None;intro_text=None;recognized_question=None;first_response_deadline=None
            def may_speak():
                import re
                return audio is None or not panels.preferences.called_only or bool(recognized_question and re.search(r'\b(?:cronos|kronos|chronos)\b',recognized_question,re.I))
            async def ready(reply):
                nonlocal spoken
                if spoken is None and may_speak():
                    spoken=reply
                    delivery.mark('answer_received',characters=len(reply))
                    if first_response_deadline is not None:first_response_deadline.reschedule(None)
                    await queue.put({'type':'reply','reply':reply,'session_id':str(session)})
            async def intro(text):
                nonlocal intro_text
                if intro_text is not None or not may_speak():return
                intro_text=text
                delivery.mark('answer_received',characters=len(text))
                if first_response_deadline is not None:first_response_deadline.reschedule(None)
                await queue.put({'type':'intro','reply':text,'session_id':str(session)})
            async def transcript(text):
                nonlocal recognized_question
                recognized_question=text
                delivery.mark('question_recognized',characters=len(text))
                delivery.mark('question_received',characters=len(text))
                await queue.put({'type':'transcript','text':text})
            async def run():
                with delivery.scope(request.app.state.delivery,request.headers.get('x-cronos-turn')):
                    delivery.mark('audio_received',bytes=len(audio)) if audio is not None else delivery.mark('question_received',characters=len(message))
                    nonlocal first_response_deadline
                    token=reply_sink.set(ready);intro_token=intro_sink.set(intro);transcript_token=transcript_sink.set(transcript)
                    try:
                        async with asyncio.timeout(CONVERSATION_FIRST_REPLY_TIMEOUT_SECONDS) as deadline:
                            first_response_deadline=deadline
                            async with request.app.state.lock:
                                try:
                                    try:
                                        options={'audio':audio} if audio is not None else {}
                                        if heard_context:options['heard_context']=heard_context
                                        result=await request.app.state.engine.chat(session,message,**options)
                                    except ProviderError as exc:
                                        if audio is None or audio_fallback is None or (exc.kind!='audio_transcription_missing' and not exc.retryable) or spoken is not None or intro_text is not None:
                                            raise
                                        recognized=recognized_question or await transcribe_fallback(audio_fallback)
                                        if not recognized:raise ProviderError('A gravação foi mantida, mas não consegui reconhecer a pergunta. Tente novamente ou use o botão de envio de texto.',502) from None
                                        if not recognized_question:await transcript(recognized)
                                        if panels.preferences.called_only and not re.search(r'\b(?:cronos|kronos|chronos)\b',recognized,re.I):
                                            result={'session_id':str(session),'reply':'','recognized_text':recognized,'ignored':True,'topics':[],'notes':[],'tool_results':[],'warnings':[],'timings_ms':{}}
                                        else:
                                            result=await request.app.state.engine.chat(session,recognized,**({'heard_context':heard_context} if heard_context else {}))
                                            result['recognized_text']=recognized
                                finally:request.app.state.engine.phase='idle'
                        if not result.get('ignored') and ((spoken is not None and spoken!=result['reply']) or (intro_text is not None and not result['reply'].startswith(intro_text))):
                            raise ProviderError('A resposta transmitida não corresponde ao resultado final.',502)
                        request.app.state.features.record('language','passed','Conversa processada e salva.')
                        await queue.put({'type':'result','result':result})
                    except TimeoutError:
                        await queue.put({'type':'error','status':504,'detail':{'message':'Não consegui iniciar a resposta dentro do prazo de recuperação. Sua pergunta foi preservada; tente novamente sem repetir.'}})
                    except ProviderError as exc:
                        detail={'message':str(exc)}
                        if isinstance(exc,TurnError):detail.update(session_id=str(exc.session),tool_results=exc.results)
                        await queue.put({'type':'error','status':exc.status,'detail':detail})
                    except (OSError,ValueError):
                        await queue.put({'type':'error','status':500,'detail':{'message':'Não foi possível ler ou salvar personalidade/memória.'}})
                    except Exception:
                        await queue.put({'type':'error','status':500,'detail':{'message':'Falha ao concluir a conversa.'}})
                    finally:
                        reply_sink.reset(token);intro_sink.reset(intro_token);transcript_sink.reset(transcript_token)
            task=asyncio.create_task(run())
            try:
                while True:
                    event=await queue.get()
                    yield json.dumps(event,ensure_ascii=False)+'\n'
                    if event['type'] in {'result','error'}:break
            finally:
                task.cancel()
                with suppress(asyncio.CancelledError):await task
                panels.active-=1;panels.requests+=1
        return StreamingResponse(events(),media_type='application/x-ndjson',headers={'Cache-Control':'no-store','X-Accel-Buffering':'no'})

    @app.post("/chat/stream", dependencies=[Depends(authenticate)])
    async def stream_chat(body: ChatInput, request: Request):
        if not body.message.strip():raise HTTPException(422,"A mensagem não pode ser vazia.")
        return await conversation_stream(body.session_id or uuid4(),body.message,request,heard_context=body.heard_context)

    @app.post('/chat/audio/stream',dependencies=[Depends(authenticate)])
    async def stream_audio(request: Request,session_id: UUID | None = None):
        current=request.app.state.engine.settings
        if current.privacy_mode!='online' or current.provider!='gemini' or current.gemini_transport!='live':
            raise HTTPException(503,'Conversa por áudio direto requer o Gemini Live já configurado e modo online.')
        if request.headers.get('content-type','').split(';')[0]!='audio/wav':raise HTTPException(415,'Envie áudio WAV PCM mono de 16 kHz.')
        chunks=[];size=0
        async for chunk in request.stream():
            size+=len(chunk)
            if size>2*1024*1024:raise HTTPException(413,'Áudio ultrapassa o limite de 2 MiB.')
            chunks.append(chunk)
        from cronos.recognition import read_pcm,check_signal
        audio_wav=b''.join(chunks)
        try:
            pcm=read_pcm(audio_wav)
            check_signal(pcm)
        except ValueError as exc:raise HTTPException(422,str(exc)) from None
        from urllib.parse import unquote
        heard_context=unquote(request.headers.get('X-Cronos-Heard-Context','')[:30000])[:10000] or None
        return await conversation_stream(session_id or uuid4(),'Pergunta falada',request,pcm,audio_fallback=audio_wav,heard_context=heard_context)

    @app.get("/conversations/{session_id}", dependencies=[Depends(authenticate)])
    async def conversation(session_id: UUID, request: Request):
        events = request.app.state.memory.tool_history(session_id)
        resolved = {event.get('approval_id') for event in events if event['status'] != 'pending_confirmation'}
        for event in events:
            if event['status'] == 'pending_confirmation' and event.get('approval_id') not in request.app.state.registry.pending:
                event['status'] = 'resolved' if event.get('approval_id') in resolved else 'expired'
        return {"session_id": str(session_id), "messages": request.app.state.memory.history(session_id),
                "tool_results": events}

    from cronos.evolution import install_api
    install_api(app, authenticate)

    @app.get("/providers", dependencies=[Depends(authenticate)])
    async def providers():
        try:
            return {"providers": provider_catalog(app.state.engine.settings), "selected": app.state.engine.settings.provider}
        except ProviderError as exc:
            raise HTTPException(503, str(exc)) from exc

    @app.get("/providers/{provider_id}/models", dependencies=[Depends(authenticate)])
    async def models(provider_id: str):
        try:
            return {"provider": provider_id, "models": await available_models(app.state.engine.settings, provider_id)}
        except ProviderError as exc:
            raise HTTPException(503, str(exc)) from exc

    @app.get("/tools", dependencies=[Depends(authenticate)])
    async def tools(request: Request):
        return {"tools": request.app.state.registry.catalog(), "plugin_errors": request.app.state.registry.load_errors}

    @app.post("/tools/approvals/{approval_id}", dependencies=[Depends(authenticate)])
    async def approve(approval_id: UUID, body: ApprovalInput, request: Request):
        async with request.app.state.lock:
            try:
                result = await request.app.state.registry.resolve(str(approval_id), body.accepted, body.session_id)
                request.app.state.memory.log_tool(body.session_id, result)
                return result
            except ToolError as exc:
                raise HTTPException(409, str(exc)) from exc

    @app.post("/memory/search", dependencies=[Depends(authenticate)])
    async def memory_search(body: MemoryQuery, request: Request):
        async with request.app.state.lock:
            return {"notes": request.app.state.memory.search(body.query, body.limit)}

    @app.get("/memory/graph", dependencies=[Depends(authenticate)])
    async def memory_graph(request: Request, offset: int = Query(0, ge=0), limit: int = Query(600, ge=1, le=1000)):
        return await asyncio.to_thread(request.app.state.memory.graph, offset, limit)

    @app.get("/memory/note", dependencies=[Depends(authenticate)])
    async def memory_note(path: str, request: Request):
        try:
            return {"path": path, "content": request.app.state.memory.read_note(path)}
        except (ValueError, OSError):
            raise HTTPException(404, "Nota não encontrada ou caminho inválido.")

    @app.post("/memory/sync", dependencies=[Depends(authenticate)])
    async def memory_sync(request: Request):
        memory = request.app.state.memory
        def sync():
            memory.flush_exports()
            memory.sync_notes()
            return {**memory.stats(), "warnings": memory.warnings}
        return await asyncio.to_thread(sync)

    @app.get("/memory/status", dependencies=[Depends(authenticate)])
    async def memory_status(request: Request):
        return request.app.state.memory.stats()

    async def fish_client():
        if settings.privacy_mode != 'online':
            raise HTTPException(503, "Modo local: Fish Audio está desabilitado porque envia áudio/texto a um serviço externo.")
        if not settings.fish_key:
            raise HTTPException(503, "Configure FISH_API_KEY.")
        if fish_factory:
            return fish_factory()
        from fishaudio import AsyncFishAudio
        return AsyncFishAudio(api_key=settings.fish_key, timeout=30.0)

    async def transcribe_fallback(audio_wav: bytes) -> str:
        """Recover an utterance when Gemini Live fails to emit input transcription."""
        try:return await recognize_recording(audio_wav,'audio/wav')
        except HTTPException as exc:
            raise ProviderError(str(exc.detail),504 if exc.status_code==504 else 502) from None

    active_fish_model = settings.fish_model

    async def fish_tts(client, method, **arguments):
        nonlocal active_fish_model
        model = active_fish_model

        async def request(selected):
            if selected == 's2.1-pro-free' and fish_factory is None:
                from cronos.fish_legacy import synthesize_json,stream_json
                if method=='stream':return stream_json(settings.fish_key,**arguments)
                return await synthesize_json(settings.fish_key, **arguments)
            return await getattr(client.tts, method)(model=selected, **arguments)

        return await request(model)

    @app.post("/voice/speech", dependencies=[Depends(authenticate)])
    async def speech(body: SpeechInput, request: Request):
        with delivery.scope(request.app.state.delivery,request.headers.get('x-cronos-turn')):
            delivery.mark('voice_requested',provider='fish',characters=len(body.text))
            if not body.text.strip():
                raise HTTPException(422, "Informe um texto para sintetizar.")
            reference = body.reference_id or settings.fish_reference
            if not settings.fish_model:
                raise HTTPException(503, "Configure FISH_MODEL com o modelo liberado para API na sua conta Fish Audio.")
            client = await fish_client()
            try:
                async with client:
                    audio = await voice_deadline(fish_tts(client, "convert", text=body.text, reference_id=reference or None,
                                                     format=settings.fish_format,
                                                     speed=body.speed or settings.fish_speed, latency=settings.fish_latency), VOICE_REQUEST_TIMEOUT_SECONDS)
                if not audio:raise HTTPException(502,'O Fish Audio retornou áudio vazio.')
                delivery.mark('voice_received',provider='fish',bytes=len(audio))
                request.app.state.features.record("voice", "passed", "Síntese retornou áudio; reprodução física no dispositivo não foi certificada.")
                return Response(content=audio, media_type="audio/wav" if settings.fish_format == "wav" else "audio/mpeg")
            except HTTPException as exc:
                delivery.mark('failed',provider='fish',http_status=exc.status_code,error_type='voice')
                raise
            except Exception as exc:
                delivery.mark('failed',provider='fish',error_type=type(exc).__name__)
                raise HTTPException(502, fish_error(exc, "síntese")) from exc

    @app.post('/voice/pcm',dependencies=[Depends(authenticate)])
    async def speech_pcm(body: SpeechInput,request:Request):
        with delivery.scope(request.app.state.delivery,request.headers.get('x-cronos-turn')):
            delivery.mark('voice_requested',provider='fish',characters=len(body.text))
            if settings.privacy_mode!='online' or not settings.fish_key:raise HTTPException(503,'Configure a voz Fish Audio em modo online.')
            if active_fish_model!='s2.1-pro-free':raise HTTPException(503,'Streaming PCM não habilitado para este modelo. Nenhum modelo foi trocado.')
            if not body.text.strip():raise HTTPException(422,'Informe um texto para sintetizar.')
            from cronos.fish_legacy import stream_json
            iterator=stream_json(settings.fish_key,text=body.text,reference_id=body.reference_id or settings.fish_reference or None,format='pcm',speed=body.speed or settings.fish_speed,latency=settings.fish_latency)
            try:
                async with asyncio.timeout(VOICE_REQUEST_TIMEOUT_SECONDS):
                    first=await anext(iterator)
                    while len(first)<4:first+=await anext(iterator)
                delivery.mark('voice_received',provider='fish',bytes=len(first))
                if first.startswith(b'RIFF'):raise ValueError('A síntese não retornou PCM bruto.')
            except Exception as exc:
                await iterator.aclose()
                raise HTTPException(502,fish_error(exc,'síntese')) from exc
            async def chunks():
                try:
                    yield first
                    async for chunk in iterator:yield chunk
                finally:await iterator.aclose()
            return StreamingResponse(chunks(),media_type='audio/x-pcm',headers={'Cache-Control':'no-store','X-PCM-Sample-Rate':'24000','X-PCM-Channels':'1','X-PCM-Bits':'16'})

    @app.post("/voice/stream", dependencies=[Depends(authenticate)])
    async def speech_stream(body: SpeechInput):
        if not body.text.strip():
            raise HTTPException(422, "Informe um texto para sintetizar.")
        if not settings.fish_model:
            raise HTTPException(503, "Configure FISH_MODEL com o modelo liberado para API na sua conta Fish Audio.")
        client = await fish_client()
        entered = False
        try:
            await client.__aenter__()
            entered = True
            audio = await fish_tts(client, "stream", text=body.text, reference_id=body.reference_id or settings.fish_reference or None,
                                           format=settings.fish_format,
                                           speed=body.speed or settings.fish_speed, latency=settings.fish_latency)
            iterator = audio.__aiter__()
            first = await anext(iterator)
        except Exception as exc:
            if entered:
                await client.__aexit__(None, None, None)
            raise HTTPException(502, fish_error(exc, "síntese em streaming")) from None

        async def chunks():
            try:
                yield first
                async for chunk in iterator:
                    yield chunk
            except Exception:
                raise RuntimeError("O fluxo de áudio foi interrompido pelo provedor.") from None
            finally:
                await client.__aexit__(None, None, None)
        return StreamingResponse(chunks(), media_type="audio/wav" if settings.fish_format == "wav" else "audio/mpeg", headers={"Cache-Control": "no-store"})

    async def recognize_recording(audio, mime_type):
        current=app.state.engine.settings
        if current.transcription_provider=='vosk':
            try:return await asyncio.to_thread(local_recognizer.transcribe,audio)
            except ValueError as exc:raise HTTPException(503,str(exc)) from None
        if current.privacy_mode!='online':raise HTTPException(503,'Reconhecimento online desativado no modo local.')
        from cronos.transcription import gemini_transcribe,first_valid_transcription
        async def primary():
            delivery.mark('recognition_requested',provider='fish',bytes=len(audio))
            try:
                client=await fish_client()
                async with client:
                    result=await voice_deadline(client.asr.transcribe(audio=audio,language='pt'),TRANSCRIPTION_TIMEOUT_SECONDS)
                text=getattr(result,'text','')
                delivery.mark('recognition_response',provider='fish',characters=len(text) if isinstance(text,str) else 0)
                return text
            except Exception as exc:
                delivery.mark('recognition_error',provider='fish',error_type=type(exc).__name__,http_status=getattr(exc,'status_code',getattr(exc,'status',0)) or 0)
                raise
        async def alternative():return await gemini_transcribe(current,audio,mime_type)
        try:
            async with asyncio.timeout(TRANSCRIPTION_TOTAL_TIMEOUT_SECONDS):
                return await first_valid_transcription(primary,alternative if current.gemini_key.strip() else None)
        except TimeoutError:
            raise HTTPException(504,'O reconhecimento continua indisponível. Sua gravação pode ser reenviada sem repetir a fala.') from None
        except HTTPException:raise
        except ProviderError as exc:raise HTTPException(exc.status,str(exc)) from None
        except Exception as exc:raise HTTPException(502,fish_error(exc,'transcrição do microfone')) from None

    @app.post('/voice/check',dependencies=[Depends(authenticate)])
    async def check_voice_delivery(request: Request):
        import base64
        from cronos.conversation_transport import conversation_provider
        from cronos.evolution import ResilientProvider
        current=app.state.engine.settings
        with delivery.scope(app.state.delivery) as turn:
            stage='answer'
            try:
                async with asyncio.timeout(25):
                    a,b=secrets.randbelow(70)+10,secrets.randbelow(70)+10
                    question=f'Quanto é {a} mais {b}? Responda somente o número inteiro do resultado.'
                    delivery.mark('question_received',characters=len(question))
                    delivery.mark('answer_requested',provider=current.provider,characters=len(question))
                    result=await ResilientProvider(current,app.state.engine.provider or conversation_provider(current)).reply('Responda à pergunta aritmética sem usar ferramentas.',[{'role':'user','content':question}])
                    answer=result.get('reply','').strip()
                    delivery.mark('answer_received',provider=result.get('provider_used',current.provider),characters=len(answer))
                    numbers=re.findall(r'\d+',answer)
                    if result.get('tool_calls') or not numbers or numbers[-1]!=str(a+b):
                        raise ProviderError('A integração respondeu, mas não devolveu o resultado esperado ao teste. Uma saudação não é uma resposta válida.',502)
                    stage='voice';delivery.mark('voice_requested',provider='fish',characters=len(answer))
                    client=await fish_client()
                    async with client:
                        audio=await fish_tts(client,'convert',text=answer,reference_id=current.fish_reference or None,format=current.fish_format,speed=current.fish_speed,latency=current.fish_latency)
                    if not audio or len(audio)>2*1024*1024:raise ValueError('invalid diagnostic audio')
                    delivery.mark('voice_received',provider='fish',bytes=len(audio))
                    return {'turn_id':turn,'answer':answer,'audio_base64':base64.b64encode(audio).decode(),'mime_type':'audio/wav' if current.fish_format=='wav' else 'audio/mpeg'}
            except TimeoutError:
                delivery.mark('failed',error_type=stage+'_timeout',http_status=504)
                raise HTTPException(504,'O teste não completou IA e voz em 25 segundos. Confira a última etapa confirmada abaixo.') from None
            except HTTPException as exc:
                delivery.mark('failed',error_type=stage,http_status=exc.status_code);raise
            except ProviderError as exc:
                delivery.mark('failed',provider=current.provider,error_type=type(exc.__cause__).__name__ if exc.__cause__ else stage,http_status=exc.http_status or exc.status)
                raise HTTPException(exc.status,str(exc)) from None
            except Exception as exc:
                delivery.mark('failed',error_type=type(exc).__name__,http_status=502)
                raise HTTPException(502,'A integração não concluiu o teste. Confira a etapa registrada abaixo.') from None

    @app.get('/voice/delivery',dependencies=[Depends(authenticate)])
    async def voice_delivery():
        current=app.state.engine.settings
        return {'turns':app.state.delivery.snapshot(),'configured':{'gemini':bool(current.gemini_key),'fish':bool(current.fish_key),'provider':current.provider,'gemini_model':current.gemini_model,'voice_model':current.fish_model},'target_seconds':25}

    @app.post("/voice/transcribe", dependencies=[Depends(authenticate)])
    async def transcribe(request: Request):
        # Corpo binário: não precisa de multipart ou base64.
        with delivery.scope(request.app.state.delivery,request.headers.get('x-cronos-turn')):
            chunks,size=[],0
            async for chunk in request.stream():
                size+=len(chunk)
                if size>10*1024*1024:raise HTTPException(413,'Limite de áudio: 10 MiB.')
                chunks.append(chunk)
            delivery.mark('audio_received',bytes=size)
            if not size:raise HTTPException(422,'Envie um arquivo de áudio no corpo da requisição.')
            if request.headers.get('content-type','').split(';')[0]=='audio/wav':
                from cronos.recognition import read_pcm,check_signal
                try:check_signal(read_pcm(b''.join(chunks)))
                except ValueError as exc:raise HTTPException(422,str(exc)) from None
            try:
                text=await recognize_recording(b''.join(chunks),request.headers.get('content-type','audio/webm'))
                delivery.mark('question_recognized',characters=len(text))
                return {'text':text}
            except HTTPException as exc:
                delivery.mark('failed',http_status=exc.status_code,error_type='recognition')
                raise

    from cronos.studio.routes import install_studio
    install_studio(app, authenticate)
    from cronos.documents import install_documents
    install_documents(app, authenticate)
    from cronos.studies import install_studies
    install_studies(app, authenticate)
    install_routes(app, authenticate)
    install_panels(app, authenticate)
    install_geography(app, authenticate)
    return app


app = create_app()


def fish_error(exc, operation="voz"):
    prefix = f"Fish Audio — {operation}: "
    from fishaudio.exceptions import AuthenticationError, RateLimitError, NotFoundError, PermissionError, ValidationError
    if isinstance(exc, AuthenticationError):
        return "Fish Audio: chave rejeitada. Confira FISH_API_KEY e reinicie o Cronos."
    if isinstance(exc, RateLimitError):
        return prefix + "HTTP 429: limite de chamadas atingido. Aguarde antes de tentar novamente."
    if isinstance(exc, NotFoundError):
        return "Fish Audio: voz ou recurso não encontrado. Confira o ID da voz e o modelo."
    if isinstance(exc, PermissionError):
        return "Fish Audio: acesso negado para esta chave ou voz."
    if isinstance(exc, ValidationError):
        return "Fish Audio: parâmetros ou áudio não aceitos. Confira formato, voz e velocidade."
    if getattr(exc, "status", None) == 402:
        return prefix + "HTTP 402: o provedor recusou esta chamada por cobrança ou acesso. Isso não confirma saldo zerado. Confira se a chave pertence à conta com créditos e se esse recurso da API está liberado."
    return "Fish Audio indisponível; confira conexão, voz, modelo e conta."
