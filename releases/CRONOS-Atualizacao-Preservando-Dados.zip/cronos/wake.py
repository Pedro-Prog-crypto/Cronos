"""Escuta local opcional para ativar, pausar e retomar o Cronos por voz."""
import argparse
import hashlib
import importlib.util
import json
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
import time
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import httpx

from cronos.security import safe_path
from cronos.windows_agent import safe_extract

MODEL_NAME = "vosk-model-small-pt-0.3"
MODEL_URL = "https://alphacephei.com/vosk/models/" + MODEL_NAME + ".zip"
DEFAULT_SETTINGS = {
    "activation_phrase": "cronos",
    "pause_phrase": "pausar cronos",
    "resume_phrase": "retomar cronos",
    "show_phrase": "abrir cronos",
    "background_enabled": True,
    "screen_enabled": True,
    "start_with_windows": False,
}
PHRASES = {"abrir cronos", "abrir kronos", "cronos abrir", "kronos abrir"}  # compatibilidade antiga
MODEL_LAYOUTS = (("am/final.mdl", "conf/model.conf"),
                 ("final.mdl", "mfcc.conf", "HCLr.fst", "Gr.fst"))
WAKE_VERSION = 12
WAKE_GREETING = "Pois não, senhor? O que deseja?"


def normalize_phrase(value):
    if not isinstance(value, str):
        return ""
    value = "".join(character for character in unicodedata.normalize("NFKD", value.casefold())
                    if not unicodedata.combining(character))
    return " ".join("".join(ch if ch.isalnum() else " " for ch in value).split())


def validate_settings(data):
    if not isinstance(data, dict):
        raise ValueError("As configurações do ouvinte precisam ser um objeto.")
    result = {}
    for key in ("activation_phrase", "pause_phrase", "resume_phrase", "show_phrase"):
        value = data.get(key,DEFAULT_SETTINGS[key])
        if key=='show_phrase' and key not in data and normalize_phrase(value) in {normalize_phrase(v) for v in result.values()}:
            value='mostrar janela do cronos'
        normalized = normalize_phrase(value)
        if not normalized or len(normalized) > 80 or len(normalized.split()) > 10:
            raise ValueError("Cada frase precisa ter entre 1 e 10 palavras e até 80 caracteres.")
        result[key] = " ".join(str(value).strip().split())
    if len({normalize_phrase(result[key]) for key in result}) != len(result):
        raise ValueError("Chamada, abertura, pausa e retomada precisam usar frases diferentes.")
    result["start_with_windows"] = bool(data.get("start_with_windows", False))
    result['background_enabled']=bool(data.get('background_enabled',True))
    result['screen_enabled']=bool(data.get('screen_enabled',True))
    return result


def command_phrases(config):
    """Command grammar with the chosen phrases and natural Portuguese aliases."""
    activation = config["activation_phrase"]
    normalized_activation = normalize_phrase(activation)
    commands = {}
    exact = ((config["activation_phrase"], "activate"),
             (config["pause_phrase"], "paused"),
             (config["resume_phrase"], "resumed"),
             (config.get('show_phrase','abrir cronos'),'show'))
    for phrase, action in exact:
        commands[normalize_phrase(phrase)] = action

    def alias(phrase, action):
        key = normalize_phrase(phrase)
        if key:
            commands.setdefault(key, action)

    if normalized_activation in {"cronos", "kronos", "chronos"}:
        for phrase in ("cronos", "kronos", "chronos"):
            alias(phrase, "activate")
    for phrase in ('abrir '+activation,'abre '+activation,'mostrar '+activation,'mostre '+activation,
                   'abrir cronos','abrir kronos','cronos abrir','kronos abrir','abre cronos','mostrar cronos'):
        alias(phrase,'show')
    for phrase in ('fechar cronos','ocultar cronos','minimizar cronos','esconder cronos'):
        alias(phrase,'hide')
    for phrase in ("pausar cronos", "pausa cronos", "pausar " + activation,
                   "pausa " + activation, "pausar escuta", "parar escuta"):
        alias(phrase, "paused")
    for phrase in ("retomar cronos", "voltar cronos", "ativar cronos",
                   "retomar escuta", "continuar escuta"):
        alias(phrase, "resumed")
    # The bundled Portuguese Vosk vocabulary does not contain the proper name
    # "Cronos". It commonly decodes the same pronunciation as "cromos". Keep
    # both spellings in the grammar and map them to the same safe fixed action.
    for phrase, action in tuple(commands.items()):
        phonetic = re.sub(r"\b(?:cronos|kronos|chronos)\b", "cromos", phrase)
        if phonetic != phrase:
            commands.setdefault(phonetic, action)
    return commands


def settings():
    path = root() / "settings.json"
    try:
        stored = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(stored,dict) and 'show_phrase' not in stored and normalize_phrase(stored.get('activation_phrase','')) in {'abrir cronos','abrir kronos','cronos abrir','kronos abrir'}:
            stored={**stored,'activation_phrase':'cronos','show_phrase':'abrir cronos'}
        return validate_settings(stored)
    except FileNotFoundError:
        return dict(DEFAULT_SETTINGS)
    except (OSError, ValueError, TypeError):
        # Um arquivo inválido nunca deve impedir a inicialização; status expõe o padrão.
        return {**DEFAULT_SETTINGS,'background_enabled':False,'screen_enabled':False}


def save_settings(data):
    current = settings()
    current.update(data if isinstance(data, dict) else {})
    clean = validate_settings(current)
    folder = root()
    folder.mkdir(parents=True, exist_ok=True)
    from cronos.resident import write_json
    write_json(folder/'settings.json',clean)
    return clean


def paused():
    try:
        return bool(json.loads((root() / "mode.json").read_text(encoding="utf-8")).get("paused"))
    except (OSError, ValueError, TypeError):
        return False


def set_paused(value):
    folder = root()
    folder.mkdir(parents=True, exist_ok=True)
    from cronos.resident import write_json
    write_json(folder/'mode.json',{'paused':bool(value)})


def model_present(folder):
    return any(all((folder / name).is_file() for name in layout) for layout in MODEL_LAYOUTS)


def root():
    base = Path(os.getenv("LOCALAPPDATA") or (Path.home() / ".local/share"))
    return base / "Cronos" / "wake"


def set_ui_listening(active):
    folder=root();folder.mkdir(parents=True,exist_ok=True)
    path=folder/'conversation-presence.json'
    with tempfile.NamedTemporaryFile(dir=folder,suffix='.tmp',delete=False) as output:
        temporary=Path(output.name)
        output.write(json.dumps({'listening':bool(active),'at':time.time()}).encode())
    try:temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)


def ui_is_listening():
    try:
        data=json.loads((root()/'conversation-presence.json').read_text(encoding='utf-8'))
        return data.get('listening') is True and 0<=time.time()-float(data['at'])<12
    except (OSError,ValueError,TypeError,KeyError):return False


def set_ui_open(active):
    from cronos.resident import write_json
    write_json(root()/'ui-ownership.json',{'open':bool(active),'at':time.time()})


def ui_owns_microphone():
    try:
        data=json.loads((root()/'ui-ownership.json').read_text())
        reserved=data.get('open') is True and 0<=time.time()-float(data['at'])<12
    except (OSError,ValueError,TypeError,KeyError):reserved=False
    return reserved or ui_is_listening()


def status():
    folder = root()
    installed = model_present(folder / MODEL_NAME) and (folder / "model-hashes.json").is_file()
    config = settings()
    result = {"model_installed": installed,
              "dependencies_installed": all(importlib.util.find_spec(name) is not None for name in ("vosk", "sounddevice")),
              "state": "stopped", "local_only": True,
              "phrases": [config["activation_phrase"]], "settings": config,
              "paused": paused()}
    try:
        data = json.loads((folder / "status.json").read_text())
        age = time.time() - float(data["heartbeat"])
        if 0 <= age < 20 or data.get("state") == "error":
            result.update({key: data[key] for key in ("state", "last_opened", "worker_version", "last_heard",
                                                       "last_action", "last_confidence", "greeting_status", "installation", "launch_status") if key in data})
            reasons = {"dependency_missing", "microphone_unavailable", "model_or_platform_unavailable", "audio_library_or_device_unavailable", "unknown"}
            if data.get("reason") in reasons:
                result["reason"] = data["reason"]
    except (OSError, ValueError, KeyError, TypeError):
        pass
    startup = Path(os.getenv("APPDATA") or folder) / "Microsoft/Windows/Start Menu/Programs/Startup/Cronos Voice.lnk"
    result["start_with_windows"] = startup.exists()
    return result


def _write_status(state, last_opened=None, reason=None, *, last_heard=None, last_action=None,
                  last_confidence=None, greeting_status=None, launch_status=None):
    folder = root(); folder.mkdir(parents=True, exist_ok=True)
    temporary = folder / "status.tmp"
    # Heartbeats must not erase the last recognition diagnostic. Otherwise the
    # UI shows the phrase for five seconds and then silently clears it.
    try:
        previous = json.loads((folder / "status.json").read_text(encoding="utf-8"))
        if not isinstance(previous, dict):
            previous = {}
    except (OSError, ValueError, TypeError):
        previous = {}
    data = {key: previous[key] for key in
            ("last_opened", "last_heard", "last_action", "last_confidence", "greeting_status", "launch_status")
            if key in previous}
    data.update({"state": state, "heartbeat": time.time(),
                 "last_opened": last_opened if last_opened is not None else data.get("last_opened"),
                 "worker_version": WAKE_VERSION, "installation": str(Path(__file__).resolve().parent.parent)})
    if last_heard is not None:
        data["last_heard"] = str(last_heard)[:80]
    if last_action is not None:
        data["last_action"] = str(last_action)[:32]
    if last_confidence is not None:
        data["last_confidence"] = round(float(last_confidence), 3)
    if greeting_status is not None:
        data["greeting_status"] = str(greeting_status)[:24]
    if launch_status is not None:
        data["launch_status"] = launch_status
    if reason:
        data["reason"] = reason
    from cronos.resident import write_json
    try:write_json(folder/'status.json',data)
    except OSError:pass # Diagnostics must not stop a working microphone.


def prepare_model(cancel=None):
    folder = root(); folder.mkdir(parents=True, exist_ok=True)
    if (folder / MODEL_NAME).exists():
        verify_model()
        return {"installed": True, "downloaded": False}
    with tempfile.TemporaryDirectory(prefix="cronos-wake-") as temporary:
        archive = Path(temporary) / "model.zip"
        size = 0
        # URL fixa oficial. TLS permanece verificado; não segue redirects.
        with httpx.Client(timeout=httpx.Timeout(15, read=10), follow_redirects=False) as client:
            with client.stream("GET", MODEL_URL) as response:
                response.raise_for_status()
                with archive.open("wb") as file:
                    for chunk in response.iter_bytes():
                        if cancel is not None and cancel.is_set():
                            raise ValueError("Preparação interrompida; nenhum modelo foi ativado.")
                        size += len(chunk)
                        if size > 100 * 1024**2:
                            raise ValueError("Modelo excedeu o limite de download.")
                        file.write(chunk)
        extracted = Path(temporary) / "extracted"
        safe_extract(archive, extracted)
        model = extracted / MODEL_NAME
        if not model_present(model):
            raise ValueError("Pacote não contém o modelo de português esperado.")
        hashes = {}
        for file in model.rglob("*"):
            if file.is_file():
                if file.suffix.lower() in {".exe", ".dll", ".py", ".ps1", ".bat", ".cmd"}:
                    raise ValueError("O pacote contém arquivos executáveis inesperados.")
                hashes[file.relative_to(model).as_posix()] = hashlib.sha256(file.read_bytes()).hexdigest()
        import shutil
        # Destino dentro da pasta do usuário, nunca dentro do projeto/vault.
        shutil.move(str(model), str(folder / MODEL_NAME))
        (folder / "model-hashes.json").write_text(json.dumps(hashes))
        return {"installed": True, "downloaded": True, "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "note": "Hashes detectam mudanças posteriores. Não são uma assinatura independente do fornecedor."}


def verify_model():
    folder = root()
    model = safe_path(folder, MODEL_NAME, private=True)
    try:
        hashes = json.loads((folder / "model-hashes.json").read_text())
        if not isinstance(hashes, dict) or not 1 <= len(hashes) <= 1000:
            raise ValueError()
        if not any(all(name in hashes for name in layout) for layout in MODEL_LAYOUTS):
            raise ValueError()
        actual = {file.relative_to(model).as_posix() for file in model.rglob("*") if file.is_file()}
        if actual != set(hashes):
            raise ValueError()
        for name, digest in hashes.items():
            file = safe_path(model, name, private=True)
            if hashlib.sha256(file.read_bytes()).hexdigest() != digest:
                raise ValueError()
    except (OSError, ValueError, TypeError):
        raise ValueError("Modelo ausente ou alterado. Revise os arquivos do iniciador antes de ativá-lo.") from None
    return model


class Trigger:
    def __init__(self, config=None):
        self.last_activation = float("-inf")
        self.last_transition = float("-inf")
        self.config = validate_settings(config or settings())
        self.commands = command_phrases(self.config)
        self.last_heard = ""
        self.last_action = "unrecognized"
        self.last_confidence = 0.0

    def action(self, result, now=None):
        now = time.monotonic() if now is None else now
        text = normalize_phrase(result.get("text", ""))
        words = result.get("result", [])
        confidence = sum(word.get("conf", 0) for word in words) / len(words) if words else 0
        action = self.commands.get(text)
        self.last_heard = text[:80]
        self.last_confidence = confidence
        self.last_action = action or "unrecognized"
        cooldown = 2
        last_action = self.last_activation if action in {'activate','show','hide'} else self.last_transition
        if confidence < .50 or action is None or now - last_action < cooldown:
            if action is not None and confidence < .50:
                self.last_action = "low_confidence"
            return None
        if action == "paused":
            self.last_transition = now
            set_paused(True)
            return "paused"
        if action == "resumed":
            self.last_transition = now
            set_paused(False)
            return "resumed"
        if paused() and action not in {'show','hide'}:
            self.last_action = "ignored_while_paused"
            return None
        self.last_activation = now
        return action

    def accept(self, result, now=None):
        """Compatibilidade com integrações antigas que só verificam ativação."""
        return self.action(result, now) in {'activate','show'}


@contextmanager
def single_instance(name):
    if sys.platform != "win32":
        yield True
        return
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    ctypes.set_last_error(0)
    handle = kernel.CreateMutexW(None, False, "Local\\" + name)
    if not handle:
        raise ValueError("Não foi possível reservar a instância local.")
    acquired = ctypes.get_last_error() != 183
    try:
        yield acquired
    finally:
        kernel.CloseHandle(handle)


def python_windowless():
    candidate = Path(sys.executable).with_name("pythonw.exe")
    return candidate if candidate.exists() else Path(sys.executable)


def independent_environment():
    """Keep personal data settings, remove ownership of the parent server."""
    inherited = dict(os.environ)
    for key in ("CRONOS_SUPERVISED", "CRONOS_SUPERVISOR_PID", "CRONOS_MANAGED_PORT",
                "CRONOS_OPEN_BROWSER", "CRONOS_API_TOKEN"):
        inherited.pop(key, None)
    return inherited


def app_launch_module():
    """Use the standalone Cronos window when its WebView dependency exists."""
    try:
        return "cronos.desktop" if importlib.util.find_spec("webview") else "cronos.browser"
    except (ImportError, ValueError):
        return "cronos.browser"


def start():
    if sys.platform != "win32":
        raise ValueError("O iniciador deve executar no Windows do usuário.")
    verify_model()
    current = status()
    if not current["dependencies_installed"]:
        raise ValueError('Instale o extra wake: python -m pip install -e ".[wake]".')
    if current.get("state") in {"listening", "paused"}:
        if (current.get("worker_version") == WAKE_VERSION and
                current.get("installation") == str(Path(__file__).resolve().parent.parent)):
            return {"requested": True, "already_running": True,
                    "note": "O ouvinte atualizado já está ativo e carrega as frases salvas."}
        # Stop an older listener from another Cronos installation. Both builds
        # share the per-user wake folder and mutex, so otherwise its old grammar
        # could keep ignoring the newly configured commands.
        stop()
        deadline = time.monotonic() + 6
        while time.monotonic() < deadline:
            current = status()
            if current.get("state") not in {"listening", "paused"}:
                break
            time.sleep(.1)
        else:
            raise ValueError("O ouvinte antigo não encerrou. Use Parar ouvinte e tente Iniciar novamente.")
    project = Path(__file__).resolve().parent.parent
    environment=independent_environment();environment['CRONOS_WAKE_STARTED']=str(time.time())
    subprocess.Popen([str(python_windowless()), "-m", "cronos.wake"], cwd=project, shell=False, env=environment,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if settings()['start_with_windows']:
        try:startup(True)
        except (OSError,ValueError):pass
    return {"requested": True, "note": "Confira o estado do microfone após alguns segundos. Chamar o Cronos mantém a janela atual; peça abrir Cronos para mostrar a interface."}


def stop():
    folder = root(); folder.mkdir(parents=True, exist_ok=True)
    (folder / "stop.request").write_text("stop")
    return {"requested": True}


def startup(enabled):
    if sys.platform != "win32":
        raise ValueError("Inicialização automática disponível somente no Windows.")
    appdata = os.getenv("APPDATA")
    if not appdata:
        raise ValueError("Pasta de inicialização do usuário indisponível.")
    destination = Path(appdata) / "Microsoft/Windows/Start Menu/Programs/Startup/Cronos Voice.lnk"
    if not enabled:
        destination.unlink(missing_ok=True)
        save_settings({"start_with_windows": False})
        return {"start_with_windows": False, "note": "Não encerra o ouvinte atual; use Parar microfone."}
    verify_model()
    if not status()["dependencies_installed"]:
        raise ValueError("Instale as dependências do iniciador antes de ativar o início automático.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    def literal(value):
        return "'" + str(value).replace("'", "''") + "'"
    script = "$s=(New-Object -ComObject WScript.Shell).CreateShortcut(" + literal(destination) + ");"
    script += "$s.TargetPath=" + literal(python_windowless()) + ";$s.Arguments='-m cronos.wake';"
    script += "$s.WorkingDirectory=" + literal(Path(__file__).resolve().parent.parent) + ";$s.Description='Cronos: comando de voz local';$s.Save()"
    import ctypes
    directory = ctypes.create_unicode_buffer(32768)
    if not ctypes.windll.kernel32.GetWindowsDirectoryW(directory, len(directory)):
        raise ValueError("Diretório do Windows indisponível.")
    executable = Path(directory.value) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    process = subprocess.run([str(executable), "-NoProfile", "-NonInteractive", "-Command", script],
                             shell=False, capture_output=True, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
    if process.returncode or not destination.exists():
        raise ValueError("O Windows não confirmou a criação do atalho.")
    save_settings({"start_with_windows": True})
    return {"start_with_windows": True}


def speak_activation_greeting(speaking=None,*,respect_ui=False):
    """Speak the wake acknowledgement with the configured Cronos voice when possible."""
    if sys.platform != "win32":
        return "unavailable"
    project = Path(__file__).resolve().parent.parent
    try:
        from dotenv import load_dotenv
        from cronos.persistent_data import selected_home, POINTER
        home = (Path(os.environ["CRONOS_DATA_HOME"]) if os.getenv("CRONOS_DATA_HOME") else
                selected_home(project) if (project / POINTER).exists() else project)
        load_dotenv(home / ".env", override=True)
        from cronos.config import Settings
        configured = Settings.from_env()
        if configured.privacy_mode == "online" and configured.fish_key and configured.fish_model:
            import asyncio
            import winsound
            from fishaudio import AsyncFishAudio

            async def synthesize():
                if configured.fish_model == 's2.1-pro-free':
                    from cronos.fish_legacy import synthesize_json
                    return await synthesize_json(configured.fish_key, text=WAKE_GREETING,
                        reference_id=configured.fish_reference or None, format='wav',
                        speed=configured.fish_speed, latency=configured.fish_latency)
                client = AsyncFishAudio(api_key=configured.fish_key, timeout=5.0)
                async with client:
                    return await client.tts.convert(
                        model=configured.fish_model, text=WAKE_GREETING,
                        reference_id=configured.fish_reference or None,
                        format="wav", speed=configured.fish_speed, latency=configured.fish_latency)

            async def bounded():
                return await asyncio.wait_for(synthesize(), timeout=5)
            from cronos.fish_legacy import finalize_wav
            identity = hashlib.sha256(json.dumps([WAKE_GREETING, configured.fish_key,
                configured.fish_model, configured.fish_reference, configured.fish_speed,
                configured.fish_latency]).encode()).hexdigest()[:24]
            cache = root() / ("greeting-" + identity + ".wav")
            audio = None
            try:
                if cache.stat().st_size <= 1024 * 1024:
                    audio = finalize_wav(cache.read_bytes())
            except (OSError, ValueError):
                pass
            if audio is None:
                audio = finalize_wav(asyncio.run(bounded()))
                try:
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    with tempfile.NamedTemporaryFile(dir=cache.parent, suffix=".tmp", delete=False) as output:
                        temporary = Path(output.name)
                        output.write(audio)
                    try: temporary.replace(cache)
                    finally: temporary.unlink(missing_ok=True)
                    for old in cache.parent.glob("greeting-*.wav"):
                        if old != cache: old.unlink(missing_ok=True)
                except OSError:
                    pass  # A read-only cache must never silence a successful voice response.
            if speaking: speaking.set()
            try:
                if respect_ui and ui_owns_microphone():return 'conversation_active'
                winsound.PlaySound(audio, winsound.SND_MEMORY | winsound.SND_NODEFAULT)
            finally:
                if speaking: speaking.clear()
            return "cronos_voice"
    except Exception:
        pass
    # Offline fallback: use an installed Portuguese Windows speech voice. The
    # command is constant, hidden, and never includes user-provided text.
    try:
        if respect_ui and ui_owns_microphone():return 'conversation_active'
        import ctypes
        from ctypes import wintypes
        directory = ctypes.create_unicode_buffer(32768)
        if not ctypes.windll.kernel32.GetWindowsDirectoryW(directory, len(directory)):
            return "unavailable"
        executable = Path(directory.value) / "System32/WindowsPowerShell/v1.0/powershell.exe"
        script = "$v=New-Object -ComObject SAPI.SpVoice; $voices=$v.GetVoices(); "
        script += "for($i=0;$i -lt $voices.Count;$i++){if($voices.Item($i).GetDescription() -match 'Portugu|Brazil|Brasil|Francisca'){ $v.Voice=$voices.Item($i); break }}; "
        script += "$null=$v.Speak('Pois não, senhor? O que deseja?')"
        if speaking: speaking.set()
        try:
            process = subprocess.run([str(executable), "-NoProfile", "-NonInteractive", "-Command", script],
                                     shell=False, capture_output=True, timeout=8,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        finally:
            if speaking: speaking.clear()
        return "windows_voice" if process.returncode == 0 else "unavailable"
    except Exception:
        return "unavailable"


def listen():
    if sys.platform != 'win32':raise ValueError('Execute no seu Windows.')
    from cronos.background_listener import run
    return run()


def main():
    parser = argparse.ArgumentParser(description="Abrir Cronos por voz, localmente")
    parser.add_argument("--stop", action="store_true")
    args = parser.parse_args()
    try:
        if args.stop:
            stop()
        else:
            listen()
    except KeyboardInterrupt:
        _write_status("stopped")
    except Exception as exc:
        reason = ("dependency_missing" if isinstance(exc, ImportError) else
                  "microphone_unavailable" if exc.__class__.__name__ == "PortAudioError" else
                  "model_or_platform_unavailable" if isinstance(exc, ValueError) else
                  "audio_library_or_device_unavailable" if isinstance(exc, OSError) else "unknown")
        _write_status("error", reason=reason)
        print("O iniciador não pôde ativar o microfone/modelo. Consulte Dispositivos no Cronos.")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
